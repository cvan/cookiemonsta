(function() {
    var div = document.querySelector('div');
    div.innerHTML = '<dl><dt>document.cookie</dt><dd>' + document.cookie + '</dd></dl>';
})();
