(function() {
    var div = document.querySelector('div');
    div.innerHTML = document.cookie;
})();
